/*42935863*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tipoT.h"

bool esMayor (tipoT t1, tipoT t2){
	if(t1>t2)
		return true;
	else
		return false;
}

bool esMenor (tipoT t1, tipoT t2){
	if(t1<t2)
		return true;
	else
		return false;
}

bool esIgual (tipoT t1, tipoT t2){
	if(t1==t2)
		return true;
	else
		return false;
}

