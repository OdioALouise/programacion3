/*42935863*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Cola.h"

struct AuxCola{
	tipoT valor;
	struct AuxCola* siguiente;
};


void crearCola (Cola & c){
	c=NULL;
}

void encolar (tipoT t, Cola &c){
	Cola cola=new AuxCola;
	cola->valor=t;
	cola->siguiente=NULL;

	if(esVaciaCola(c))
		c=cola;
	else{

		Cola actual=new AuxCola;
		actual=c;
		
		Cola auxiliar = new AuxCola;
		auxiliar=actual;

		while( !esVaciaCola(actual))
		{
			auxiliar=actual;
			actual=actual->siguiente;
		}	
			auxiliar->siguiente=cola;
	}

}


bool esVaciaCola (Cola c){
	if(!c)
		return true;
	return false;
}


tipoT frente (Cola c){
	return c->valor;
}

void desencolar (Cola &c){
	Cola actual=new AuxCola;
	actual=c;
	delete actual;
	actual=NULL;
	c=c->siguiente;

}

void destruirCola (Cola &c){
	Cola actual=new AuxCola;

	while(!esVaciaCola(c))
	{
		actual=c;
		delete actual;
		actual=NULL;
		c=c->siguiente;
	}
}


