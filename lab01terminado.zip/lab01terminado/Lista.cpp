/*42935863*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Lista.h"

struct AuxLista{
	tipoT valor;
	AuxLista* siguiente;
};


void crearLista (Lista &l){
	l=NULL;
}


void consLista (tipoT t, Lista &l){

	Lista aux=new AuxLista;
	aux->valor=t;


	if(esVaciaLista(l)){
	        aux->siguiente=NULL;
		l=aux;
	}else{
		aux->siguiente=l;
		l=aux;
	}
}



bool esVaciaLista (Lista l){
	if(!l)
		return true;
	return false;
}


void restoLista (Lista & l){
	l=l->siguiente;
}


tipoT primeroLista (Lista l){
	return l->valor;
}


void destruirLista (Lista &l){
	Lista aux;

	while(!esVaciaLista(l))
	{
		aux=l;
		restoLista(l);
		delete aux;
		aux=NULL;
	}
}

