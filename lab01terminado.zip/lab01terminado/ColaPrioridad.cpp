/*42935863*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ColaPrioridad.h"


struct AuxColaPrioridad{
	tipoT valor;
	tipoT prioridad;
	AuxColaPrioridad* siguiente;
};

static tipoT cotaCP;

void crearColaPrioridad (ColaPrioridad &cp, int tamanio){
	cp=NULL;
	cotaCP=tamanio;
}


bool esLlenaColaPrioridad (ColaPrioridad cp){
tipoT contador=0;
ColaPrioridad actual=new AuxColaPrioridad;
actual=cp;

while(!esVaciaColaPrioridad(actual))
{
	contador++;
	actual=actual->siguiente;
}


if(esIgual(contador,cotaCP))
	return true;
return false;

}



bool esVaciaColaPrioridad (ColaPrioridad cp){
	if(!cp)
		return true;
	else 
		return false;
}



void encolarColaPrioridad (ColaPrioridad &cp, tipoT t, int prio){
	ColaPrioridad colaprioridad=new AuxColaPrioridad;
	colaprioridad->valor=t;
	colaprioridad->prioridad=abs(prio);

	if(esVaciaColaPrioridad(cp))
		cp=colaprioridad;
	else{
		if( esMenor(colaprioridad->prioridad, cp->prioridad) ){
			colaprioridad->siguiente=cp;
			cp=colaprioridad;
			}
		else{
			ColaPrioridad actual =new AuxColaPrioridad;
			ColaPrioridad auxiliar =new AuxColaPrioridad;
			actual=cp;
			auxiliar=actual;

			while(!esVaciaColaPrioridad(actual)){
				if(esMayor(colaprioridad->prioridad, actual->prioridad) || esIgual(colaprioridad->prioridad, actual->prioridad))
					auxiliar=actual;				
				actual=actual->siguiente;
			}

			colaprioridad->siguiente=auxiliar->siguiente;
			auxiliar->siguiente=colaprioridad;
			


		}
	}
}


tipoT minimoColaPrioridad (ColaPrioridad cp){
	return cp->valor;
}

void removerMinimoColaPrioridad (ColaPrioridad &cp){
	ColaPrioridad actual =new AuxColaPrioridad;
	actual=cp;
	cp=cp->siguiente;
	delete actual;
	actual = NULL;	
}

void destruirColaPrioridad (ColaPrioridad &cp){
	while(!esVaciaColaPrioridad(cp))
		removerMinimoColaPrioridad(cp);
}






