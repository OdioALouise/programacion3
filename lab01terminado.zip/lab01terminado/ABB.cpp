/*42935863*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ABB.h"

struct AuxABB{
	tipoT valor;
	AuxABB* izquierda;
	AuxABB* derecha;
	Lista valores;
};

void insertarNodo(tipoT t, ABB &abb);
void eliminarNodos(ABB &abb);

void crearABB (ABB &abb){
abb=NULL;
}

bool agregarABB (tipoT t, ABB &abb){

	if(esVacioABB(abb)){

		ABB nodo=new AuxABB;
		nodo->izquierda=NULL;
		nodo->derecha=NULL;
		nodo->valor=t;
		
		crearLista(nodo->valores);
		consLista(t, nodo->valores);
		abb=nodo;

		return true;	

	}else{

	Lista actual=abb->valores;

	while(!esVaciaLista(actual)){
 

		if(esIgual(primeroLista(actual), t)){
 
			return false;
		
		}
		restoLista(actual);

	}	


		insertarNodo(t, abb);
	}

	consLista(t, abb->valores);
	return true;
}

void insertarNodo(tipoT t, ABB &abb){

	if( esMenor(t,abb->valor) ){
		if(esVacioABB(abb->izquierda)){
			ABB nodo=new AuxABB;
			nodo->izquierda=NULL;
			nodo->derecha=NULL;
			nodo->valor=t;
			abb->izquierda=nodo;
		}else{
			insertarNodo(t, abb->izquierda);
		}
	}else if(esMayor(t, abb->valor)){
		if(esVacioABB(abb->derecha)){

			ABB nodo=new AuxABB;
			nodo->izquierda=NULL;
			nodo->derecha=NULL;
			nodo->valor=t;
			abb->derecha=nodo;
		}else{

			insertarNodo(t, abb->derecha);
		}

		}
}


bool esVacioABB (ABB abb){
	if(!abb)
		return true;
	return false;
}


ABB arbolIzquierdo (ABB abb){
	return abb->izquierda;
}

ABB arbolDerecho (ABB abb){
	return abb->derecha;
}

tipoT valorABB (ABB abb){
	return abb->valor;
}


void eliminarNodos(ABB &abb){
	if(abb->izquierda!=NULL){
		eliminarNodos(abb->izquierda);
	}else if(abb->derecha!=NULL){
		eliminarNodos(abb->derecha);

	}else if(abb->izquierda==NULL && abb->derecha==NULL){
		abb=NULL;
		return;
	}
}


void destruirABB (ABB &abb){
	destruirLista(abb->valores);
	while(!esVacioABB(abb))
		eliminarNodos(abb);
}



